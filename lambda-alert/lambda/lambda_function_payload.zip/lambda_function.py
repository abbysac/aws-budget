
import json
import boto3

ses = boto3.client('ses', region_name="us-east-1")  # Update to your SES region

SENDER_EMAIL = "abbysac@gmail.com"  # Replace with your SES-verified email
RECIPIENT_EMAIL = "camleous@yahoo.com"  # Replace with recipient email

def lambda_handler(event, context):
    print("🚀 Received Event:", json.dumps(event, indent=2))

    # Extract SNS message
    if "Records" in event and isinstance(event["Records"], list):
        try:
            sns_message = event["Records"][0]["Sns"]["Message"]
            message = json.loads(sns_message)  # Convert to dictionary
        except (KeyError, IndexError, json.JSONDecodeError) as e:
            print(f"⚠️ Error parsing SNS message: {str(e)}")
            return {"statusCode": 400, "body": "Invalid SNS event format"}
    else:
        print("⚠️ Direct Budget event received, using raw event.")
        message = event

    # Extract budget details
    budget_name = message.get("budgetName", "billing-alert")
    alert_type = message.get("alertType", "ACTUAL")
    amount = message.get("amount", "2.00")

    subject = f"AWS Budget Alert: {budget_name}"
    body = f"""🚨 AWS Budget Alert Triggered!

🔹 **Budget Name:** {budget_name}
🔹 **Alert Type:** {alert_type}
🔹 **Amount:** {amount}

📜 Full Message:
{json.dumps(message, indent=2)}
"""

    # Send email via SES
    response = ses.send_email(
        Source=SENDER_EMAIL,
        Destination={'ToAddresses': [RECIPIENT_EMAIL]},
        Message={
            'Subject': {'Data': subject},
            'Body': {'Text': {'Data': body}}
        }
    )

    print(f"✅ Email sent! Message ID: {response['MessageId']}")
    return {"statusCode": 200, "body": "Email sent successfully"}
